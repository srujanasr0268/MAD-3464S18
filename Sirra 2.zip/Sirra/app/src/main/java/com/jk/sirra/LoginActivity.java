package com.jk.sirra;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener{

    Button btnLogin;
    Button btnRegister;
    EditText edtEmail;
    EditText edtPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        btnLogin =  findViewById(R.id.btnLogin);
        btnLogin.setOnClickListener(this);

        btnRegister = findViewById(R.id.btnRegister);
        btnRegister.setOnClickListener(this);

        edtEmail = findViewById(R.id.edtEmail);
        edtPassword = findViewById(R.id.edtPassword);


        }

    @Override
    public void onClick(View view) {

        if (view.getId() == btnLogin.getId()) {
            String email = edtEmail.getText().toString();
            String password = edtPassword.getText().toString();

                    if(email.equals("test") &&  password.equals("test")) {
                        Toast.makeText(this, "Login sucessful", Toast.LENGTH_SHORT).show();
                    }else{
                Toast.makeText(this, "Invalid Username/password", Toast.LENGTH_SHORT).show();
                    }
//            Toast.makeText(this, "button clicked", Toast.LENGTH_SHORT).show();
        }else if(view.getId() == btnRegister.getId()){
            Toast.makeText( this, "Register clicked", Toast.LENGTH_SHORT).show();

            Intent registerIntent = new Intent( this, RegisterActivity.class);
            startActivity(registerIntent);
        }

    }
}
